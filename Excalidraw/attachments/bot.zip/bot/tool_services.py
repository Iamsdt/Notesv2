from typing import Annotated

from langchain_core.messages import ToolMessage
from langchain_core.tools import tool
from langchain_core.tools.base import InjectedToolCallId
from langchain_openai import OpenAIEmbeddings
from tortoise import Tortoise

from src.app.core.config.settings import get_settings
from src.app.db.tables.services_table import ServiceTable


@tool
async def get_service_information(
    tool_call_id: Annotated[str, InjectedToolCallId],
    service_id: int | None,
    service_title: str | None,
    query: str | None,
):
    """
    Fetches service information.
    Use query to search about service based on service, medications, treatments, etc,
    """

    if service_id:
        service = await ServiceTable.filter(id=service_id).first()
        if not service:
            return ToolMessage(
                content=f"No service found with id {service_id}",
                tool_call_id=tool_call_id,
                status="error",
            )

        data = {
            "id": service.id,
            "title": service.title,
            "description": service.description,
        }
        return ToolMessage(
            content=f"Service information: {data}",
            data=data,
            tool_call_id=tool_call_id,
            status="success",
        )

    if service_title:
        service = await ServiceTable.filter(title__icontains=service_title).first()
        if not service:
            return ToolMessage(
                content=f"No service found with title {service_title}",
                tool_call_id=tool_call_id,
                status="error",
            )

        # media_info = await ServiceMediaTable.filter(service=service.id).all()

        data = {
            "id": service.id,
            "title": service.title,
            "description": service.description,
            # "meta": service.meta,
            # "media_info": [
            #     {
            #         "title": media.title,
            #         "description": media.description,
            #         "file_link": media.file_link,
            #         "source": media.source,
            #     }
            #     for media in media_info
            # ],
        }
        return ToolMessage(
            content=f"Service information {data}",
            data=data,
            tool_call_id=tool_call_id,
            status="success",
        )

    if query:
        embeddings = OpenAIEmbeddings(
            model="text-embedding-3-small", api_key=get_settings().OPENAI_API_KEY
        )
        query_embeddings = await embeddings.aembed_query(query)
        vector_string = str(query_embeddings)

        sql = """
        WITH ranked_media AS (
            SELECT
                sm.service_id,
                sm.title,
                sm.file_link,
                sm.source,
                ROW_NUMBER() OVER (PARTITION BY sm.id
                    ORDER BY s.embeddings <=> $1::vector
                ) AS rank
            FROM t_service_media sm
            JOIN t_services s ON sm.service_id = s.id
        )
        SELECT
            s.id AS service_id,
            s.title,
            s.description,
            s.meta,
            COALESCE(
                jsonb_agg(
                    DISTINCT jsonb_build_object('title', rm.title, 'file_link',
                    rm.file_link, 'source', rm.source)
                ) FILTER (WHERE rm.rank <= 3),
                '[]'::jsonb
            ) AS media_info
        FROM t_services s
        LEFT JOIN ranked_media rm ON s.id = rm.service_id
        GROUP BY s.id
        ORDER BY s.embeddings <=> $1::vector
        LIMIT 10;
        """
        conn = Tortoise.get_connection("master")
        results = await conn.execute_query_dict(sql, [vector_string])
        # Remove the incorrect dict conversion
        print("***************** Service Task", results)
        if not results:
            return ToolMessage(
                content=f"No service found with query {query} in the database",
                tool_call_id=tool_call_id,
                status="error",
            )

        return ToolMessage(
            content=f"Service information: {results}",
            data=results,
            tool_call_id=tool_call_id,
            status="success",
        )

    return ToolMessage(
        content="Please provide either service_id, service_title or query to fetch service information",  # noqa: E501
        tool_call_id=tool_call_id,
        error={"message": "Invalid input"},
        status="error",
    )
