from collections.abc import Sequence
from typing import Annotated

from langchain_core.messages import BaseMessage
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import END, MessagesState, StateGraph
from langgraph.graph.message import add_messages
from langgraph.managed.is_last_step import RemainingSteps
from langgraph.prebuilt import ToolNode

from src.app.utils.bot.agent_helper import AgentHelper
from src.app.utils.bot.booking_node import BookingNode
from src.app.utils.bot.master_node import MasterNode
from src.app.utils.bot.tool_appointment import manage_appointment
from src.app.utils.bot.tool_doctors import get_doctor_information
from src.app.utils.bot.tool_human_request import request_to_human
from src.app.utils.bot.tool_services import get_service_information
from src.app.utils.bot.tool_summary import get_context


# def manage_list(existing: list, updates: Union[list, dict]):
#     ids = []
#     messages = []
#     updates: list[BaseMessage] = Converter.convert_dict_to_message(updates)
#     existing: list[BaseMessage] = Converter.convert_dict_to_message(existing)
#     for i in existing:
#         if i.id in ids:
#             continue

#         ids.append(i.id)
#         messages.append(i)

#     for i in updates:
#         if i.id in ids:
#             continue
#         ids.append(i.id)
#         messages.append(i)

#     print("********Final messages", messages)
#     return messages


class AgentState(MessagesState):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    remaining_steps: RemainingSteps


class WhatsAppBotApp:
    def __init__(self):
        self.master = MasterNode()
        self.booking = BookingNode()

    def build_graph(self, checkpoint: BaseCheckpointSaver):
        # generate database
        master_tools = ToolNode(
            [
                get_doctor_information,
                get_service_information,
                manage_appointment,
                get_context,
                request_to_human,
            ]
        )

        # booking_tools = ToolNode(
        #     [
        #         manage_appointment,
        #         # manage_cab_order,
        #         get_doctor_information,
        #         get_context,
        #         request_to_human,
        #     ]
        # )

        graph = StateGraph(MessagesState)
        # Add nodes
        graph.add_node("MASTER", self.master.build_node())
        # graph.add_node("BOOKING", self.booking.build_node())
        graph.add_node("master_tools", master_tools)
        # graph.add_node("booking_tools", booking_tools)
        # graph.add_node(
        #     "remove_failed_tool_call_attempt", AgentHelper.remove_failed_tool_call_attempt
        # )

        # Add edges
        graph.add_edge("master_tools", "MASTER")
        # graph.add_edge("booking_tools", "BOOKING")
        # graph.add_edge("remove_failed_tool_call_attempt", "MASTER")
        graph.add_conditional_edges(
            "MASTER",
            AgentHelper.master_to_subtask,
            # {"tools": "master_tools", "BOOKING": "BOOKING", "END": END},
            {"tools": "master_tools", "END": END},
        )

        # graph.add_conditional_edges("master_tools", AgentHelper.should_fallback)

        # graph.add_conditional_edges(
        #     "BOOKING",
        #     AgentHelper.booking_to_subtask,
        #     {"tools": "booking_tools", "END": END},
        # )

        graph.set_entry_point("MASTER")
        return graph.compile(checkpointer=checkpoint)
