from datetime import UTC, datetime
from typing import Annotated, Literal, Union

import pytz
from langchain_core.messages import ToolMessage
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool
from langchain_core.tools.base import InjectedToolCallId

from src.app.db.tables.appointment_table import AppointmentTable


status_to_text = {
    0: "Pending approval",
    1: "Approved",
    2: "Rejected",
}


def parse_datetime(dt_value):
    """Parse various datetime strings into a timezone-aware datetime."""
    if isinstance(dt_value, datetime):
        return dt_value

    if not dt_value:
        return None

    kolkata_tz = pytz.timezone("Asia/Kolkata")
    formats = [
        ("%Y-%m-%d %H:%M:%S.%f%z", True),  # e.g. 2025-04-02 14:30:00.000+0000
        ("%Y-%m-%d %H:%M:%S%z", True),  # e.g. 2025-04-02 14:30:00+0000
        ("%Y-%m-%dT%H:%M:%S.%fZ", False),  # e.g. 2025-04-02T14:30:00.000000Z → Asia/Kolkata
        ("%Y-%m-%d %H:%M:%S", False),  # e.g. 2025-04-02 14:30:00
        ("%Y-%m-%d %H:%M", False),  # e.g. 2025-04-02 14:30
        ("%Y-%m-%d", False),  # e.g. 2025-04-02
    ]

    for fmt, has_offset in formats:
        try:
            dt = datetime.strptime(dt_value, fmt)
            if has_offset:
                return dt  # tz-aware
            if fmt.endswith("Z"):
                return kolkata_tz.localize(dt)  # treat Z as Asia/Kolkata
            return dt  # still naive
        except (ValueError, TypeError):
            continue

    return None


def convert_to_utc(dt_value):
    """Normalize to UTC, assuming Asia/Kolkata for naïve datetimes."""
    dt = parse_datetime(dt_value)
    if dt is None:
        return None

    if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
        kolkata_tz = pytz.timezone("Asia/Kolkata")
        dt = kolkata_tz.localize(dt)

    return dt.astimezone(UTC)


async def get_appointment(
    appointment_id: int,
    thread_id: str,
) -> AppointmentTable | None:
    """Get appointment by ID."""
    return await AppointmentTable.filter(
        id=appointment_id,
        patient_id=thread_id,
    ).first()


async def get_appointments(
    thread_id: str,
    limit: int = 10,
) -> list[AppointmentTable]:
    """Get last N appointments."""
    return (
        await AppointmentTable.filter(patient_id=thread_id)
        .prefetch_related("doctor")
        .order_by("-modified_at")
        .limit(limit)
    )


def convert_appointment_json(appointments: list[AppointmentTable]) -> dict:
    """Convert appointment to JSON format."""
    ist_tz = pytz.timezone("Asia/Kolkata")

    return [
        {
            "appointment_id": appointment.id,
            "appointment_status": status_to_text.get(appointment.appointment_status, "Unknown"),
            "approved_at": appointment.approved_at,
            "appointment_date": appointment.appointment_date.astimezone(ist_tz).strftime(
                "%Y-%m-%d %H:%M:%S %Z%z"
            ),
            "doctor_name": getattr(appointment.doctor, "name", "Unknown"),
            "symptoms": appointment.symptoms,
            "reason": appointment.reason,
            "addition_notes": appointment.addition_notes,
            "modified_at": appointment.modified_at,
            "location": appointment.location,
        }
        for appointment in appointments
    ]


@tool
async def manage_appointment(
    config: RunnableConfig,
    tool_call_id: Annotated[str, InjectedToolCallId],
    appointment_id: int | None = None,
    doctor_id: int | None = None,
    symptoms: str | None = None,
    reason: str | None = None,
    action: Literal["GET", "CREATE", "DELETE", "UPDATE"] = "GET",
    location: Literal["BANJARA", "TRIMULGHERRY", "UPPAL", "MIYAPUR"] = "UPPAL",
    appointment_date_time: Union[datetime, str, None] = None,
):
    """
    Manages appointment creation, retrieval, deletion, and update:

    IMPORTANT: Always specify the 'action' parameter as one of: GET, CREATE, DELETE, UPDATE.

    CREATE: Creates a new appointment. REQUIRED fields:
        - doctor_id: Get this from get_doctor_information tool
        - appointment_date_time: Format as YYYY-MM-DDThh:mm:ss.000Z
        - symptoms or reason: Describe patient's symptoms
        - location: Branch name (BANJARA, TRIMULGHERRY, UPPAL, MIYAPUR)

    GET: Retrieves appointment(s):
        - With appointment_id: Gets specific appointment
        - Without appointment_id: Gets all patient appointments

    DELETE: Cancels an appointment:
        - REQUIRED: appointment_id
        - Note: Only pending appointments can be cancelled

    UPDATE: Modifies an existing appointment:
        - REQUIRED: appointment_id
        - Optional: symptoms, reason, appointment_date_time, location
        - Note: Only pending appointments can be updated
    """
    # Parse the appointment_date_time if it's a string
    parsed_date_time = convert_to_utc(appointment_date_time)

    if action not in ["GET", "CREATE", "DELETE", "UPDATE"]:
        return ToolMessage(
            content="Wrong action provided. Please use one of [GET, CREATE, DELETE] actions.",
            tool_call_id=tool_call_id,
        )

    thread_id = config.get("configurable", {}).get("thread_id")

    # CREATE Appointment
    if action == "CREATE":
        # Check for required fields
        missing_fields = []
        if not doctor_id:
            missing_fields.append(
                "doctor's id missing, use get_doctor_information tool to get doctor's id"
            )
        if parsed_date_time is None and appointment_date_time is not None:
            missing_fields.append("Invalid date time format. Please provide a valid date and time.")
        elif parsed_date_time is None:
            missing_fields.append("Date time is missing. Please ask user to share appointment date")

        if missing_fields:
            return ToolMessage(
                content=f"Please provide the following required information: {', '.join(missing_fields)}.",
                tool_call_id=tool_call_id,
            )

        # Create appointment with optional fields defaulting to None
        try:
            table = await AppointmentTable.create(
                patient_id=thread_id,
                doctor_id=doctor_id,
                symptoms=symptoms,
                reason=reason,
                appointment_date=parsed_date_time,
                location=location,
            )

            # After successful creation, prompt for optional information if not provided
            optional_fields_missing = []
            if not symptoms:
                optional_fields_missing.append("symptoms")
            if not reason:
                optional_fields_missing.append("reason")
            if not appointment_date_time:
                optional_fields_missing.append("appointment date time")

            response_content = "New appointment created successfully."
            if optional_fields_missing:
                response_content += (
                    f"\nWould you like to provide any of the following optional information? "
                    f"{', '.join(optional_fields_missing)}"
                )

            return ToolMessage(
                content=response_content,
                data={
                    "appointment_id": table.id,
                    "appointment_status": status_to_text[table.appointment_status],
                },
                tool_call_id=tool_call_id,
            )
        except Exception as e:
            return ToolMessage(
                content=f"Error creating appointment: {e}",
                tool_call_id=tool_call_id,
            )

    # GET Appointment
    if action == "GET":
        if appointment_id:
            appointment: AppointmentTable = await get_appointment(
                appointment_id=appointment_id,
                thread_id=thread_id,
            )
            output = convert_appointment_json([appointment])
            return ToolMessage(
                content=f"Appointment Found details: {output[0]}.",
                tool_call_id=tool_call_id,
            )

        appointments: list[AppointmentTable] = await get_appointments(
            thread_id=thread_id,
        )
        if not appointments:
            return ToolMessage(
                content="No appointments found.",
                tool_call_id=tool_call_id,
            )
        output_list = convert_appointment_json(appointments)
        return ToolMessage(
            content=f"Found total {len(output_list)} appointments. Ask user to choose the right "
            f"appointments: Appointment Details: {output_list}.",
            tool_call_id=tool_call_id,
        )

    # DELETE Appointment
    if action == "DELETE":
        appointment: AppointmentTable = await AppointmentTable.filter(
            id=appointment_id,
            patient_id=thread_id,
        ).first()
        if not appointment:
            appointments: list[AppointmentTable] = await get_appointments(
                thread_id=thread_id,
            )
            if not appointments:
                return ToolMessage(
                    content="No appointments found.",
                    tool_call_id=tool_call_id,
                )
            output_list = convert_appointment_json(appointments)
            return ToolMessage(
                content=f"Found total {len(output_list)} appointments. Ask user to choose the right "
                f"appointments: Appointment Details: {output_list}.",
                tool_call_id=tool_call_id,
            )

        # check if appointment is approved
        if appointment.appointment_status == 0:
            appointment.appointment_status = 2
            appointment.addition_notes = "Cancelled by patient"
            await appointment.save()

            return ToolMessage(
                content="Appointment has been cancelled successfully.",
                tool_call_id=tool_call_id,
            )

        return ToolMessage(
            content="Approved appointment cannot be deleted. Only pending appointments can be deleted.",
            tool_call_id=tool_call_id,
        )

    if action == "UPDATE":
        # IF its approved then it should not be updated
        # Talk with human
        appointment = await AppointmentTable.filter(
            id=appointment_id,
            patient_id=thread_id,
        ).first()
        if not appointment:
            appointments: list[AppointmentTable] = await get_appointments(
                thread_id=thread_id,
            )
            if not appointments:
                return ToolMessage(
                    content="No appointments found.",
                    tool_call_id=tool_call_id,
                )
            output_list = convert_appointment_json(appointments)
            return ToolMessage(
                content=f"Found total {len(output_list)} appointments. Ask user to choose the right "
                f"appointments: Appointment Details: {output_list}.",
                tool_call_id=tool_call_id,
            )

        if appointment.appointment_status != 0:
            return ToolMessage(
                content="Approved appointments cannot be updated. Only pending appointments can be updated.",
                tool_call_id=tool_call_id,
            )

        appointment.symptoms = symptoms or appointment.symptoms
        appointment.reason = reason or appointment.reason
        appointment.appointment_date = parsed_date_time or appointment.appointment_date
        appointment.location = location or appointment.location

        await appointment.save()

        return ToolMessage(
            content=f"Appointment with ID {appointment.id} updated successfully.",
            tool_call_id=tool_call_id,
        )

    return ToolMessage(
        content="Unexpected error occurred.",
        tool_call_id=tool_call_id,
    )
