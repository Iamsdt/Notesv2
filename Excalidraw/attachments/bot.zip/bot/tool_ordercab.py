from typing import Annotated, Literal

from langchain_core.messages import ToolMessage
from langchain_core.tools import tool
from langchain_core.tools.base import InjectedToolCallId

from src.app.db.tables.appointment_table import AppointmentTable
from src.app.db.tables.orders_table import OrderTable


status_to_text = {
    0: "Pending approval",
    1: "Approved",
    2: "Rejected",
}


@tool
async def manage_cab_order(
    tool_call_id: Annotated[str, InjectedToolCallId],
    order_id: int | None,
    appointment_id: int | None,
    location: str | None,
    location_coordinates: str | None = None,
    action: Literal["GET", "CREATE", "DELETE"] = "GET",
):
    """
    Manages cab orders by creating or updating an order in the database
    based on the given workflow.
    """

    # Two possible scenarios:
    # GET and create, update
    content = "Wrong action provided. Please provide a valid action. [GET, CREATE, DELETE]"

    if action == "GET" and not order_id:
        content = "Please provide an order ID to get the order details."

    if action == "GET":
        order = await OrderTable.filter(id=order_id).first()
        if not order:
            content = f"Order with ID {order_id} does not exist."
        else:
            return ToolMessage(
                content="Order details fetched successfully.",
                data={
                    "order_id": order.id,
                    "order_status": status_to_text[order.order_status],
                    "accepted_time": order.accepted_time,
                },
                tool_call_id=tool_call_id,
            )

    if action == "CREATE" and appointment_id and location:
        appointment = await AppointmentTable.filter(id=appointment_id).first()
        if not appointment:
            content = f"Appointment with ID {appointment_id} does not exist."

        if appointment.appointment_status != 1:
            content = "Appointment is not approved yet. Please wait for approval."

        else:
            # TODO: parse the location and get the coordinates
            def is_valid_coordinates(coords: str) -> bool:
                try:
                    if not coords or "," not in coords:
                        return False
                    lat, lon = map(float, coords.split(","))
                    return -90 <= lat <= 90 and -180 <= lon <= 180
                except ValueError:
                    return False

            if location_coordinates and not is_valid_coordinates(location_coordinates):
                return ToolMessage(
                    content="Invalid location coordinates. Format should be 'latitude,longitude' with valid ranges.",
                    tool_call_id=tool_call_id,
                )

            print("Location coordinates:", location_coordinates)

            new_order = await OrderTable.create(
                appointment_id=appointment_id,
                order_status=0,
                location=location,
                location_cords=location_coordinates,
            )

            return ToolMessage(
                content="New order created successfully.",
                data={
                    "order_id": new_order.id,
                    "appointment_id": appointment_id,
                    "order_status": status_to_text[new_order.order_status],
                },
                tool_call_id=tool_call_id,
            )

    if action == "CREATE" and (not appointment_id or not location):
        content = "Please provide an appointment ID and location to create a new order."

    if action == "DELETE" and order_id:
        order = await OrderTable.filter(id=order_id).first()
        if not order:
            content = "Order with ID {order_id} does not exist."
        else:
            await order.delete()
            return ToolMessage(
                content=f"Order with ID {order_id} deleted successfully.",
                tool_call_id=tool_call_id,
            )

    elif action == "DELETE" and not order_id:
        content = "Please provide an order ID to delete the order."

    return ToolMessage(
        content=content,
        tool_call_id=tool_call_id,
    )
