from typing import Literal

from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    RemoveMessage,
    ToolMessage,
    trim_messages,
)
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI


class AgentHelper:
    @staticmethod
    def create_agent_without_tools(llm: ChatOpenAI, system_prompt: str):
        """
        This function is used to create an agent with the given LLM model and system prompt.
        :param llm: llm model
        :param system_prompt: system prompt
        :return: agent
        """
        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="messages"),
                # MessagesPlaceholder(variable_name="agent_scratchpad"),
            ]
        )
        return prompt | llm

    @staticmethod
    def create_agent_without_tools_message(llm: ChatOpenAI, system_prompt: str):
        """
        This function is used to create an agent with the given LLM model and system prompt.
        :param llm: llm model
        :param system_prompt: system prompt
        :return: agent
        """
        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                # MessagesPlaceholder(variable_name="messages"),
                # MessagesPlaceholder(variable_name="agent_scratchpad"),
            ]
        )
        return prompt | llm

    # create a new function with tools
    @staticmethod
    def create_agent_with_tools(llm: ChatOpenAI, tools: list, system_prompt: str):
        """
        This function is used to create an agent with the given LLM model, tools and system prompt.
        :param llm: llm model
        :param tools: list of tools
        :param system_prompt: system prompt
        :return: agent
        """
        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="messages"),
            ]
        )
        return prompt | llm.bind_tools(tools)

    @staticmethod
    def agent_node(state, agent, name):
        res = agent.invoke(state)
        if isinstance(res, AIMessage):
            return {
                "messages": [AIMessage(content=res.content, name=name)],
            }
        return {
            "messages": [AIMessage(content=res["output"], name=name)],
        }

    @staticmethod
    def create_agent_executor(llm: ChatOpenAI, tools: list, system_prompt: str):
        """
        This function is used to create an agent with the given LLM model, tools and system prompt.
        :param llm: llm model
        :param tools: list of tools
        :param system_prompt: system prompt
        :return: agent
        """
        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="messages"),
                MessagesPlaceholder(variable_name="agent_scratchpad"),
            ]
        )
        agent = create_openai_functions_agent(llm, tools, prompt)
        return AgentExecutor(agent=agent, tools=tools)

    @staticmethod
    def master_to_subtask(state):
        last_message = state["messages"][-1]
        # if "BOOKING" in last_message.content.upper():
        #     return "BOOKING"

        if "remaining_steps" in state and state["remaining_steps"] <= 2:
            return "END"

        if last_message.tool_calls:
            return "tools"

        return "END"

    @staticmethod
    def booking_to_subtask(state):
        last_message = state["messages"][-1]

        if "remaining_steps" in state and state["remaining_steps"] <= 2:
            return "END"

        if last_message.tool_calls:
            return "tools"

        return "END"

    @staticmethod
    def remove_failed_tool_call_attempt(state):
        messages = state["messages"]
        # Remove all messages from the most recent
        # instance of AIMessage onwards.
        last_ai_message_index = next(
            i for i, msg in reversed(list(enumerate(messages))) if isinstance(msg, AIMessage)
        )
        messages_to_remove = messages[last_ai_message_index:]
        return {"messages": [RemoveMessage(id=m.id) for m in messages_to_remove]}

    @staticmethod
    def should_fallback(
        state,
    ) -> Literal["MASTER", "remove_failed_tool_call_attempt"]:
        messages = state["messages"]
        failed_tool_messages = [
            msg
            for msg in messages
            if isinstance(msg, ToolMessage) and msg.additional_kwargs.get("error") is not None
        ]
        if failed_tool_messages:
            return "remove_failed_tool_call_attempt"
        return "MASTER"

    @staticmethod
    def trim_state_messages(
        messages: list[BaseMessage],
        current_message: BaseMessage,
        mex_tokens: int = 500,
    ):
        trim_list = trim_messages(
            messages,
            token_counter=ChatOpenAI(model="gpt-4o-mini"),
            max_tokens=mex_tokens,
            start_on="human",
            end_on=("human"),
            include_system=False,
            allow_partial=False,
        )

        trim_list.append(current_message)
        final_message = []
        ids = [i.id for i in trim_list]
        for i in messages:
            if i.id not in ids:
                final_message.append(RemoveMessage(id=i.id))

        # now merge with trim_list
        final_message.extend(trim_list)
        return final_message
