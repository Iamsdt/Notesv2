import functools
from datetime import datetime

from langchain_core.messages import BaseMessage
from langchain_openai import ChatOpenAI

from src.app.core.config.settings import get_settings
from src.app.utils.bot.agent_helper import AgentHelper
from src.app.utils.bot.tool_appointment import manage_appointment
from src.app.utils.bot.tool_doctors import get_doctor_information
from src.app.utils.bot.tool_human_request import request_to_human
from src.app.utils.bot.tool_summary import get_context


class BookingNode:
    def __init__(self):
        self.BOOKING_PROMPT = """
    You are the appointment specialist for Citi Neuro Centre hospital. 
    You've been activated because the master agent identified an appointment-related request.
    Today's Date: {date} (Asia/Kolkata)

    # Your Role
    - You ONLY handle appointment-related tasks (booking, updating, canceling, or retrieving)
    - Continue the conversation where the master agent left off
    - Access conversation history with get_context if needed

    # Available Tools
    - manage_appointment: Create (action="CREATE"), update (action="UPDATE"), retrieve (action="GET"), or cancel (action="DELETE") appointments
    - get_doctor_information: Verify doctor availability and specialization (doctor_id, doctor_name, or query parameter)
    - get_context: Retrieve conversation history when needed
    - request_to_human: For complex cases only (use sparingly)

    # Required Information for Booking
    1. Doctor information (validated via get_doctor_information)
    2. Symptoms and reason for visit
    3. Preferred date/time (in Asia/Kolkata timezone)
    4. Branch location (BANJARA, TRIMULGHERRY, UPPAL, or MIYAPUR)

    # Process Workflow
    1. Review the user's request to determine the specific appointment action needed
    2. Collect missing information through conversation
    3. Verify doctor availability and appropriate specialization match
    4. Confirm all details with user before executing any action
    5. Use the appropriate tool to complete the request
    6. Provide clear confirmation and next steps

    # Important Rules
    - Always verify a doctor is available before booking
    - Only pending appointments can be updated/canceled
    - Approved appointments cannot be modified
    - Match doctor specialization with patient symptoms and needs
    - Use plain text responses formatted for WhatsApp (use *asterisks* for emphasis)
    """

    @staticmethod
    async def build_booking(state, agent, name):
        messages: list[BaseMessage] = state["messages"]
        new_state = {
            "messages": messages,
            "date": datetime.now().strftime("%A, %B %d, %Y %H:%M:%S"),
        }
        res = await agent.ainvoke(new_state)

        final_messages = AgentHelper.trim_state_messages(
            messages=messages,
            current_message=res,
        )

        return {"messages": final_messages}

    def build_node(self):
        model_name = "gpt-4.1-nano"  # "deepseek/deepseek-chat:free"
        master_agent = AgentHelper.create_agent_with_tools(
            llm=ChatOpenAI(
                model=model_name,
                temperature=0.0,
                api_key=get_settings().OPENAI_API_KEY,
            ),
            system_prompt=self.BOOKING_PROMPT,
            tools=[
                manage_appointment,
                get_doctor_information,
                get_context,
                request_to_human,
            ],
        )

        return functools.partial(
            BookingNode.build_booking,
            agent=master_agent,
            name="booking",
        )
