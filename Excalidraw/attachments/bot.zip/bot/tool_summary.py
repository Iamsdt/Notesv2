from datetime import UTC, datetime, timedelta
from typing import Annotated

from langchain.prompts import PromptTemplate
from langchain_core.messages import BaseMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool
from langchain_core.tools.base import InjectedToolCallId
from langchain_openai import ChatOpenAI
from tortoise.expressions import Q

from src.app.core.config.settings import get_settings
from src.app.db.checkpoint.converter import Converter
from src.app.db.tables.chats_table import MessageTable, ThreadTable


@tool
async def get_context(
    config: RunnableConfig,
    tool_call_id: Annotated[str, InjectedToolCallId],
):
    """
    This tool retrieves the last 50 chat messages from a thread
    and creates an AI-generated summary. Can be used to retrieve context
    """
    thread_id = config.get("configurable", {}).get("thread_id")
    thread: ThreadTable = await ThreadTable.get(thread_id=thread_id)

    # Check if summary exists and is recent (within last 5 minutes)
    if thread.summary and thread.summary_generated_at:
        time_difference = datetime.now(UTC) - thread.summary_generated_at
        if time_difference < timedelta(minutes=5):
            return ToolMessage(
                content=f"Chat Summary: {thread.summary}",
                data={"thread_id": thread_id, "summary": thread.summary, "cached": True},
                tool_call_id=tool_call_id,
            )

    # Get last 30 chats ordered by creation date
    chats: list[dict] = (
        await MessageTable.filter(
            Q(Q(thread_id=thread_id), ~Q(type=3), join_type="AND"),
        )
        .order_by("-created_at")
        .limit(50)
        .values("content")
    )

    SUMMARY_TEMPLATE = """
        Below is a conversation between a Human and an AI Assistant.
        Please provide a concise summary of the key points discussed:
        {chat_history}
        <Instruction>
        Keep the summary to 100 words or less.
        </Instruction>
        Summary:
    """

    prompt = PromptTemplate(input_variables=["chat_history"], template=SUMMARY_TEMPLATE)

    # Initialize the LLM
    llm = ChatOpenAI(
        temperature=0,
        model="gpt-4.1-nano",
        api_key=get_settings().OPENAI_API_KEY,
    )

    # Format chat history
    chat_history: list[BaseMessage] = Converter.convert_dict_to_messages(chats)
    formatted_chat_history = []
    for chat in chat_history:
        formatted_chat_history.append(f"Role: {chat.type}, content: {chat.content}")

    # Join formatted chat history and generate AI summary
    formatted_history = "\n".join(formatted_chat_history)
    summary_result = await llm.ainvoke(prompt.format(chat_history=formatted_history))

    # Clean and format the summary
    summary = summary_result.content
    thread.summary = summary
    thread.summary_generated_at = datetime.now(UTC)
    await thread.save()

    return ToolMessage(
        content=f"Chat Summary: {summary}",
        data={"thread_id": thread_id, "summary": summary, "message_count": len(chats)},
        tool_call_id=tool_call_id,
    )
