# import functools
# from datetime import datetime

# from langchain_core.messages import BaseMessage
# from langchain_openai import ChatOpenAI

# from src.app.core.config.settings import get_settings
# from src.app.utils.bot.agent_helper import AgentHelper
# from src.app.utils.bot.tool_appointment import manage_appointment
# from src.app.utils.bot.tool_doctors import get_doctor_information
# from src.app.utils.bot.tool_ordercab import manage_cab_order
# from src.app.utils.bot.tool_summary import get_context


# class BookingNode:
#     def __init__(self):
#         self.BOOKING_PROMPT = """
#     Determine the user's intent in their interaction with the Citi Neuro Centre hospital
#     bot for booking appointments and cab services via WhatsApp. Depending on the recognized
#     intent, call the appropriate tool among the available options.
#     Today's Date: {date}

#     For appointment bookings, ensure all necessary information is collected and confirmed
#     with the user before creating the appointment.

#     # Tools and Their Usage
#     - **manage_appointment**: Use for scheduling appointments with doctors.
#         - Collect information: doctor_name, symptoms, reason, additional_notes, appointment_date_time.
#         - Confirm with the user before creating the appointment.
#         - tools invocation:
#             - **get_doctor_information**: Retrieve doctor details based on the provided name.
#             - **manage_appointment**: when all information is collected with action "CREATE"
#     - **manage_cab_order**: Utilize when the user intends to book a cab service.
#         - Collect information: location, and appointment. Without booking an appointment,
#         the cab cannot be ordered.
#         - Confirm with the user before creating the cab order.
#         - tools invocation:
#             - **manage_appointment**: Check if an appointment exists for the user.
#             - **manage_cab_order**: when all information is collected with action "CREATE",
#             user will share location, and you need to convert the location to coordinates (latitude,longitude) in string,
#             and call the tool with both location and location_coordinates.
#     - **get_doctor_information**: Retrieve details about a specific doctor.
#     - **get_context**: Access user chat history context for better interaction understanding.

#     # Steps

#     1. **Intent Recognition**: Determine whether the user's request pertains to bookings
#         (appointment or cab) or information retrieval.
#     2. **Information Collection**: If the intent is appointment booking, gather all relevant
#         details such as doctor_name, symptoms, reason, and additional_notes.
#     3. **User Confirmation**: Before proceeding with the appointment booking, confirm the
#         gathered information with the user.
#     4. **Tool Invocation**: Based on the confirmed intent, call the appropriate
#         tool with the collected data.

#     # Output Format

#     - Provide concise information about detected intent.
#     - Structured call to the relevant tool with necessary parameters in JSON format.

#     # Examples

#     **Example 1**:
#     - **User Input**: "I want to book an appointment with Dr. Smith next week."
#     - **Gathered Information**:
#     - doctor_name: Dr. Smith
#     - symptoms: Not specified
#     - reason: Not specified
#     - additional_notes: Not specified
#     - Ask the user for additional information like symptoms and reason for the appointment.
#     - Confirm the appointment details with the user before finalizing.

#     **Example 2**:
#     - **User Input**: "Could you arrange a cab for me?"
#     - **Gathered Information**:
#         - Location required?
#         - If appoint not found, ask the user to book an appointment first.
#         - Confirm if an order before finalizing

#     # Notes

#     - Always confirm with users to ensure the accuracy of the information before
#         finalizing the appointment.
#     - Be attentive to implicit cues or requests users might give, leveraging
#         the `get_context` tool if necessary.
#     - Ensure the bot respects user privacy and manages personal data appropriately.
#         """

#     @staticmethod
#     async def build_booking(state, agent, name):
#         messages: list[BaseMessage] = state["messages"]
#         new_state = {
#             "messages": messages,
#             "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#         }
#         res = await agent.ainvoke(new_state)
#         print("Messages .....")
#         for i in messages:
#             print(i.content)

#         final_messages = AgentHelper.trim_state_messages(
#             messages=messages,
#             current_message=res,
#         )

#         return {"messages": final_messages}

#     def build_node(self):
#         master_agent = AgentHelper.create_agent_with_tools(
#             llm=ChatOpenAI(
#                 model="gpt-4.1-nano", temperature=0.0, api_key=get_settings().OPENAI_API_KEY
#             ),
#             system_prompt=self.BOOKING_PROMPT,
#             tools=[
#                 manage_appointment,
#                 # manage_cab_order,
#                 get_doctor_information,
#                 get_context,
#             ],
#         )

#         return functools.partial(
#             BookingNode.build_booking,
#             agent=master_agent,
#             name="booking",
#         )
