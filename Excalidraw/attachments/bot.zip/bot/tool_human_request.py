from typing import Annotated

from langchain_core.messages import ToolMessage
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool
from langchain_core.tools.base import InjectedToolCallId

from src.app.db.tables.chats_table import ThreadTable


@tool
async def request_to_human(
    tool_call_id: Annotated[str, InjectedToolCallId],
    config: RunnableConfig,
):
    """
    Sends a request to a human staff member for assistance. Use this tool when:

    1. Handling complex medical questions beyond basic doctor recommendations
    2. Dealing with appointment modifications for already-approved appointments
    3. When information returned by other tools is unclear or insufficient
    4. For special requests that require human judgment

    This will flag the conversation for staff review, and a human will respond shortly.
    """
    thread_id = config.get("configurable", {}).get("thread_id")

    thread = await ThreadTable.get(thread_id=thread_id)
    thread.is_requested = True
    await thread.save()

    return ToolMessage(
        content="Current thread is now requested state, Human will be verify and respond soon.",
        data={
            "thread_id": thread.thread_id,
            "phone_number": thread.phone_number,
            "is_requested": thread.is_requested,
        },
        tool_call_id=tool_call_id,
    )
