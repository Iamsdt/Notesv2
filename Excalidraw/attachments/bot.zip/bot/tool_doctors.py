from typing import Annotated, Literal

from langchain_core.messages import ToolMessage
from langchain_core.tools import tool
from langchain_core.tools.base import InjectedToolCallId
from langchain_openai import OpenAIEmbeddings
from tortoise import Tortoise

from src.app.core import logger
from src.app.core.config.settings import get_settings
from src.app.db.tables.doctors_table import DoctorTable


async def get_doctor_vi_query(
    query: str,
    location: str,
    tool_call_id: str,
):
    embeddings = OpenAIEmbeddings(
        model="text-embedding-3-small", api_key=get_settings().OPENAI_API_KEY
    )
    query_embeddings = await embeddings.aembed_query(query)
    vector_string = str(query_embeddings)

    sql = """
            WITH ranked_media AS (
                SELECT
                    dm.doctor_id,
                    dm.title,
                    dm.file_link,
                    dm.source,
                    ROW_NUMBER() OVER (PARTITION BY dm.id
                        ORDER BY d.embeddings <=> $1::vector
                    ) AS rank
                FROM t_doctor_media dm
                JOIN t_doctors d ON dm.doctor_id = d.id
            )
            SELECT
                d.id AS doctor_id,
                d.name,
                d.designation,
                d.qualifications,
                d.meta,
                d.location,
                d.schedule as availability,
                COALESCE(
                    jsonb_agg(
                        DISTINCT jsonb_build_object(
                            'title', rm.title,
                            'file_link', rm.file_link,
                            'source', rm.source
                        )
                    ) FILTER (WHERE rm.rank <= 3),
                    '[]'::jsonb
                ) AS media_info
            FROM t_doctors d
            LEFT JOIN ranked_media rm ON d.id = rm.doctor_id
        """

    if location != "ALL":
        sql += f"""
            where d.location ilike '%{location}%'
            GROUP BY d.id
            ORDER BY d.embeddings <=> $1::vector
            limit 10;
        """
    else:
        sql += """
            GROUP BY d.id
            ORDER BY d.embeddings <=> $1::vector
            limit 10;
        """

    conn = Tortoise.get_connection("master")
    try:
        results = await conn.execute_query_dict(sql, [vector_string])
        return ToolMessage(
            content=f"Doctor information fetched successfully for query {query}: {results}",
            data=results,  # Pass results directly without converting to dict
            tool_call_id=tool_call_id,
            status="success",
        )
    except Exception as e:
        logger.error(f"Error in fetching doctor information for query {query}: {e}")
        return ToolMessage(
            content=f"Error in fetching doctor information for query {query}",
            tool_call_id=tool_call_id,
            status="error",
        )


@tool
async def get_doctor_information(
    doctor_id: int | None,
    doctor_name: str | None,
    query: str | None,
    tool_call_id: Annotated[str, InjectedToolCallId],
    location: Literal["ALL", "BANJARA", "TRIMULGHERRY", "UPPAL", "MIYAPUR"] = "ALL",
):
    """
    Fetches doctor information using one of these methods:

    1. By doctor_id: Gets info for a specific doctor ID

    2. By doctor_name: Searches for doctors with matching name

    3. By query: PREFERRED METHOD FOR SYMPTOMS. Use this parameter to search for doctors by:
       - Symptoms (e.g., "headache", "back pain", "dizziness")
       - Specialties (e.g., "neurology", "orthopedics", "cardiology")
       - Conditions (e.g., "stroke", "epilepsy", "arthritis")

    The location parameter can filter results to a specific branch:
    - ALL: All branches
    - BANJARA, TRIMULGHERRY, UPPAL, MIYAPUR: Specific branch

    IMPORTANT: When user mentions ANY symptoms, ALWAYS use this tool with the symptom as the query parameter.
    """

    if doctor_id:
        doctor = await DoctorTable.filter(id=doctor_id).first()
        if not doctor:
            return ToolMessage(
                content=f"No doctor found with id {doctor_id}",
                tool_call_id=tool_call_id,
                status="error",
            )

        data = {
            "id": doctor.id,
            "name": doctor.name,
            "designation": doctor.designation,
            "qualifications": doctor.qualifications,
            "meta": doctor.meta,
            "location": doctor.location,
            "availability": doctor.schedule,
        }
        return ToolMessage(
            content=f"Doctor information fetched successfully {data}",
            data=data,
            tool_call_id=tool_call_id,
            status="success",
        )

    if doctor_name:
        doctor = None
        if location != "ALL":
            doctor = await DoctorTable.filter(
                name__icontains=doctor_name,
                location__icontains=location,
            ).first()

        else:
            doctor = await DoctorTable.filter(
                name__icontains=doctor_name,
            ).first()

        # if doctor not found, try to search using query

        if not doctor:
            return await get_doctor_vi_query(doctor_name, location, tool_call_id)

        data = {
            "id": doctor.id,
            "name": doctor.name,
            "designation": doctor.designation,
            "qualifications": doctor.qualifications,
            "meta": doctor.meta,
            "location": doctor.location,
            "availability": doctor.schedule,
        }
        return ToolMessage(
            content=f"Doctor information fetched successfully for name {doctor_name}: data: {data}",
            data=data,
            tool_call_id=tool_call_id,
            status="success",
        )

    if query:
        return await get_doctor_vi_query(query, location, tool_call_id)

    return ToolMessage(
        content="Please provide either doctor_id, doctor_name or query to fetch doctor information",
        tool_call_id=tool_call_id,
        status="error",
    )
